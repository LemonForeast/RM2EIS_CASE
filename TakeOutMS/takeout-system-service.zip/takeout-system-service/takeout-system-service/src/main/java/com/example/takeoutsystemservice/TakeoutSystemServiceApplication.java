package com.example.takeoutsystemservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TakeoutSystemServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(TakeoutSystemServiceApplication.class, args);
    }

}
