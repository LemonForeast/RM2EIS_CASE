package com.example.takeoutsystemservice.api.service;

import org.springframework.stereotype.Service;

@Service
public class ThirdPartyServices {

}
