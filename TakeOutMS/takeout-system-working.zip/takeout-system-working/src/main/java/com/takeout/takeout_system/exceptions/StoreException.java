package com.takeout.takeout_system.exceptions;

public class StoreException extends RuntimeException{
    public StoreException(String message) {
        super(message);
    }
}
