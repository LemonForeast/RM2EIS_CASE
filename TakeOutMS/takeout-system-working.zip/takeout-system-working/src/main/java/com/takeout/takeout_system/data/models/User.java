package com.takeout.takeout_system.data.models;

public class User {
    private String email;
    private String password;
}
