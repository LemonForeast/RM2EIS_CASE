package com.takeout.takeout_system.services;

public interface UserService {
}
