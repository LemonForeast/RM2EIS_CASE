package com.takeout.takeout_system.services;

public class UserServiceImpl implements UserService{
}
