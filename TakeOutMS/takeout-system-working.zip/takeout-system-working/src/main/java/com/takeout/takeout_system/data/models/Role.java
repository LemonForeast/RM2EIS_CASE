package com.takeout.takeout_system.data.models;

public enum Role {
    USER,
    ADMIN;
}
