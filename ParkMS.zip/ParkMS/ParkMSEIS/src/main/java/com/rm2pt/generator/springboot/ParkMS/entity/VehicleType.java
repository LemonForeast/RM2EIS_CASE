package com.rm2pt.generator.springboot.ParkMS.entity;
public enum VehicleType {
	SMALL,
	LARGE,
	MOTOCYCLE,
	SPECIAL,
}

