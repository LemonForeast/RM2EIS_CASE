package com.rm2pt.generator.springboot.DLModelMS.utils;

public class PreconditionException extends Exception {

	public PreconditionException() {
		// TODO Auto-generated constructor stub
	}

	public PreconditionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PreconditionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PreconditionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PreconditionException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}