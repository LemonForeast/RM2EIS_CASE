package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.LoanTerm;
import com.loanprocessingsystem.repository.LoanTermRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ManageLoanTermCRUDServiceTest {

    private final Long loanTermId = 1L;

    private final Long newId = 2L;

    private final String content = "Content!";

    private ManageLoanTermCRUDService manageLoanTermCRUDService;
    @MockBean
    private LoanTermRepository loanTermRepository;


    @BeforeEach
    public void setup() {
        manageLoanTermCRUDService = new ManageLoanTermCRUDService(loanTermRepository);

        LoanTerm queriedLoanTerm = new LoanTerm(loanTermId, content);

        Mockito.when(loanTermRepository.findById(loanTermId)).thenReturn(Optional.of(queriedLoanTerm));
    }

    @Test
    void testCreateLoanTerm_thenProcessShouldBeSuccessful() {
        Mockito.when(loanTermRepository.findById(2L)).thenReturn(Optional.empty());
        boolean result =
                manageLoanTermCRUDService.createLoanTerm(2L, content);

        assertTrue(result);
    }

    @Test
    void testQueryLoanTerm_thenGetSpecifiedLoanTerm() {
        LoanTerm loanTerm =
                manageLoanTermCRUDService.queryLoanTerm(loanTermId);

        assertNotNull(loanTerm);
    }

    @Test
    void testModifyLoanTerm_thenProcessShouldBeSuccessful() {
        boolean result =
                manageLoanTermCRUDService.modifyLoanTerm(loanTermId, newId, content);

        assertTrue(result);
    }

    @Test
    void testDeleteLoanTerm_thenProcessShouldBeSuccessful() {
        boolean result =
                manageLoanTermCRUDService.deleteLoanTerm(loanTermId);

        assertTrue(result);
    }

}
