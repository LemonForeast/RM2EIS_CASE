package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.service.EnterValidatedCreditReferencesModule;
import com.loanprocessingsystem.service.GenerateLoanLetterAndAgreementModule;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(GenerateLoanLetterAndAgreementModuleController.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class GenerateLoanLetterAndAgreementModuleControllerTest {

    private final Long id = 1L;
    private final Long requestId = 2L;

    @Autowired
    private MockMvc mvc;

    @MockBean
    private GenerateLoanLetterAndAgreementModule generateLoanLetterAndAgreementModule;

    @BeforeAll
    public void setup() {
        LoanRequest loanRequest = new LoanRequest();
        loanRequest.setId(requestId);

        Mockito.when(generateLoanLetterAndAgreementModule.listApprovalRequest()).
                thenReturn(List.of(loanRequest));

        Mockito.when(generateLoanLetterAndAgreementModule.
                        generateApprovalLetter(id, requestId)).
                thenReturn(true);

        Mockito.when(generateLoanLetterAndAgreementModule.
                        emailToAppliant(requestId)).thenReturn(true);

        Mockito.when(generateLoanLetterAndAgreementModule.
                generateLoanAgreement(id, requestId)).thenReturn(true);

        Mockito.when(generateLoanLetterAndAgreementModule.
                printLoanAgreement(requestId, 5)).thenReturn(true);

    }

    @Test
    void testListApprovalRequest() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/generateLoanLetterAndAgreementModule/listApprovalRequest")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testGenerateApprovalLetter() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/generateLoanLetterAndAgreementModule/generateApprovalLetter")
                        .param("id", String.valueOf(id))
                        .param("requestId", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testEmailToAppliant() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/generateLoanLetterAndAgreementModule/emailToAppliant")
                        .param("requestId", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testGenerateLoanAgreement() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/generateLoanLetterAndAgreementModule/generateLoanAgreement")
                        .param("id", String.valueOf(id))
                        .param("requestId", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testPrintLoanAgreement() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/generateLoanLetterAndAgreementModule/printLoanAgreement")
                        .param("requestId", String.valueOf(requestId))
                        .param("number", String.valueOf(5))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

}
