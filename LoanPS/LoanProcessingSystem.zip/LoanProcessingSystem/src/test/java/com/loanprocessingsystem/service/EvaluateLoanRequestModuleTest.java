package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.CheckingAccount;
import com.loanprocessingsystem.model.entity.CreditHistory;
import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.entity.LoanTerm;
import com.loanprocessingsystem.model.enums.LoanRequestStatus;
import com.loanprocessingsystem.repository.LoanRequestRepository;
import com.loanprocessingsystem.repository.LoanTermRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EvaluateLoanRequestModuleTest {

    private final Long requestId = 1L;
    private final Long requestId2 = 2L;

    LoanRequest loanRequest1;
    LoanRequest loanRequest2;

    private EvaluateLoanRequestModule evaluateLoanRequestModule;
    @MockBean
    private LoanRequestRepository loanRequestRepository;
    @MockBean
    private LoanTermRepository loanTermRepository;


    @BeforeEach
    public void setup() {
        evaluateLoanRequestModule = new EvaluateLoanRequestModule(loanRequestRepository, loanTermRepository);
        loanRequest1 = new LoanRequest();
        loanRequest2 = new LoanRequest();
        loanRequest1.setId(requestId);
        loanRequest2.setId(requestId2);

        Mockito.when(loanRequestRepository.
                        findAllByLoanRequestStatus(LoanRequestStatus.REFERENCES_VALIDATED)).
                thenReturn(List.of(loanRequest1, loanRequest2));

        Mockito.when(loanRequestRepository.
                findById(requestId)).thenReturn(Optional.of(loanRequest1));

        Mockito.when(loanTermRepository.
                        findAll()).
                thenReturn(Collections.emptyList());
    }

    @Test
    void testListTenLoanRequest_thenGetLoanRequestList() {
        List<LoanRequest> loanRequestList =
                evaluateLoanRequestModule.listTenLoanRequest();

        assertNotNull(loanRequestList);
    }

    @Test
    void testChooseOneForReview_thenGetLoanRequest() {
        LoanRequest loanRequest =
                evaluateLoanRequestModule.chooseOneForReview(requestId);

        assertNotNull(loanRequest);
    }

    @Test
    void testCheckCreditHistory_thenProcessShouldBeSuccessful() {
        loanRequest1.setRequestedCreditHistory(new CreditHistory());
        CreditHistory creditHistory =
                evaluateLoanRequestModule.checkCreditHistory(requestId);

        assertNotNull(creditHistory);
    }

    @Test
    void testReviewCheckingAccount_thenProcessShouldBeSuccessful() {
        loanRequest1.setRequestedCAHistory(new CheckingAccount());
        CheckingAccount checkingAccount =
                evaluateLoanRequestModule.reviewCheckingAccount(requestId);

        assertNotNull(checkingAccount);
    }

    @Test
    void testListAvaiableLoanTerm_thenGetAvaliableList() {
        List<LoanTerm> loanTermList =
                evaluateLoanRequestModule.listAvaiableLoanTerm();

        assertNotNull(loanTermList);
    }

    @Test
    void testAddLoanTerm_thenProcessShouldBeSuccessful() {
        boolean result =
                evaluateLoanRequestModule.addLoanTerm(3L, requestId);

        assertTrue(result);
    }

    @Test
    void testApproveLoanRequest_thenProcessShouldBeSuccessful() {
        boolean result =
                evaluateLoanRequestModule.approveLoanRequest(requestId);

        assertTrue(result);
    }

}
