package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.Loan;
import com.loanprocessingsystem.model.entity.LoanAccount;
import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.enums.LoanStatus;
import com.loanprocessingsystem.repository.LoanAccountRepository;
import com.loanprocessingsystem.repository.LoanRepository;
import com.loanprocessingsystem.repository.LoanRequestRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class LoanProcessingSystemTest {

    private final Long requestId = 1L;

    private final Long loanId = 1L;

    private final Long accountId = 1L;

    private final LocalDate startDate = LocalDate.now();

    private final LocalDate endDate = LocalDate.now();

    private final int repaymetDays = 5;

    Loan loan;
    LoanRequest loanRequest;
    LoanAccount loanAccount;

    private LoanProcessingSystem loanProcessingSystem;
    @MockBean
    private LoanRequestRepository loanRequestRepository;
    @MockBean
    private LoanAccountRepository loanAccountRepository;
    @MockBean
    private LoanRepository loanRepository;
    @MockBean
    private ThirdPartyServices thirdPartyServices;

    @BeforeAll
    public void setup() {
        loanProcessingSystem = new LoanProcessingSystem(loanRequestRepository, loanAccountRepository,
                loanRepository, thirdPartyServices);
        loan = new Loan();
        loan.setId(loanId);

        loanRequest = new LoanRequest();
        loanRequest.setId(requestId);
        loanRequest.setEmail("ragcrix@r.com");
        loan.setReferedLoanRequest(loanRequest);

        loanAccount = new LoanAccount();
        loanAccount.setId(accountId);
    }

    @Test
    void testBookNewLoan_thenProcessShouldBeSuccessful() {
        Mockito.when(loanRequestRepository.findById(requestId)).thenReturn(Optional.of(loanRequest));
        Mockito.when(loanAccountRepository.findById(accountId)).thenReturn(Optional.of(loanAccount));
        Mockito.when(thirdPartyServices.transferFunds(accountId, loanAccount.getBalance())).thenReturn(true);
        boolean result = loanProcessingSystem.
                bookNewLoan(requestId, loanId, accountId, startDate, endDate, repaymetDays);

        assertTrue(result);
    }

    @Test
    void testGenerateStandardPaymentNotice_thenProcessShouldBeSuccessful() {
        Mockito.when(loanRepository.findAllByStatusAndCurrentOverDueDateLessThan(
                LoanStatus.LSOPEN, LocalDate.now().plusDays(3))).thenReturn(List.of(loan));
        Mockito.when(thirdPartyServices.sendEmail(any(), any(), any())).thenReturn(true);
        boolean result = loanProcessingSystem.generateStandardPaymentNotice();

        assertTrue(result);
    }

    @Test
    void testGenerateLateNotice_thenProcessShouldBeSuccessful() {
        Mockito.when(loanRepository.findAllByStatusAndCurrentOverDueDateLessThan(
                LoanStatus.LSOPEN, LocalDate.now())).thenReturn(List.of(loan));
        Mockito.when(thirdPartyServices.sendEmail(any(), any(), any())).thenReturn(true);
        boolean result = loanProcessingSystem.generateLateNotice(requestId);

        assertTrue(result);
    }

    @Test
    void testLoanPayment_thenProcessShouldBeSuccessful() {
        loan.setStatus(LoanStatus.LSOPEN);
        Mockito.when(loanRepository.findById(loanId)).thenReturn(Optional.of(loan));
        boolean result = loanProcessingSystem.loanPayment(loanId);

        assertTrue(result);
    }

    @Test
    void testCloseOutLoan_thenProcessShouldBeSuccessful() {
        loan.setStatus(LoanStatus.LSOPEN);
        Mockito.when(loanRepository.findById(loanId)).thenReturn(Optional.of(loan));
        boolean result = loanProcessingSystem.closeOutLoan(loanId);

        assertTrue(result);
    }

}
