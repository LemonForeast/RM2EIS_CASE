package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.model.entity.LoanTerm;
import com.loanprocessingsystem.service.ManageLoanTermCRUDService;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(ManageLoanTermController.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ManageLoanTermControllerTest {

    private final Long loanTermId = 1L;

    private final Long newId = 2L;

    private final String content = "Content!";

    @Autowired
    private MockMvc mvc;

    @MockBean
    private ManageLoanTermCRUDService manageLoanTermCRUDService;

    @BeforeAll
    public void setup() {
        LoanTerm queriedLoanTerm = new LoanTerm(loanTermId, content);

        Mockito.when(manageLoanTermCRUDService.createLoanTerm(
                loanTermId, content)).thenReturn(true);

        Mockito.when(manageLoanTermCRUDService.queryLoanTerm(loanTermId)).thenReturn(queriedLoanTerm);

        Mockito.when(manageLoanTermCRUDService.modifyLoanTerm(loanTermId, newId, content)).thenReturn(true);

        Mockito.when(manageLoanTermCRUDService.deleteLoanTerm(loanTermId)).thenReturn(true);
    }

    @Test
    void testCreateLoanTerm() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/manageLoanTerm/createLoanTerm")
                        .param("loanTermId", String.valueOf(loanTermId))
                        .param("content", content)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testQueryLoanTerm() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/manageLoanTerm/queryLoanTerm")
                        .param("loanTermId", String.valueOf(loanTermId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testModifyLoanTerm() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/manageLoanTerm/modifyLoanTerm")
                        .param("loanTermId", String.valueOf(loanTermId))
                        .param("newId", String.valueOf(newId))
                        .param("content", content)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testDeleteLoanTerm() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/manageLoanTerm/deleteLoanTerm")
                        .param("loanTermId", String.valueOf(loanTermId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }


}
