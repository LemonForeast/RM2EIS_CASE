package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.entity.LoanTerm;
import com.loanprocessingsystem.service.EnterValidatedCreditReferencesModule;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(EnterValidatedCreditReferencesModuleController.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EnterValidatedCreditReferencesModuleControllerTest {

    private final Long requestId = 1L;

    @Autowired
    private MockMvc mvc;

    @MockBean
    private EnterValidatedCreditReferencesModule enterValidatedCreditReferencesModule;

    @BeforeAll
    public void setup() {
        LoanRequest loanRequest = new LoanRequest();
        loanRequest.setId(requestId);

        Mockito.when(enterValidatedCreditReferencesModule.listSubmitedLoanRequest()).
                thenReturn(List.of(loanRequest));

        Mockito.when(enterValidatedCreditReferencesModule.chooseLoanRequest(requestId)).thenReturn(loanRequest);

        Mockito.when(enterValidatedCreditReferencesModule.markRequestValid(requestId)).thenReturn(true);

    }

    @Test
    void testListSubmitedLoanRequest() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/validatedCreditReferencesModule/list")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testQueryLoanTerm() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/validatedCreditReferencesModule/choose")
                        .param("requestId", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testModifyLoanTerm() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/validatedCreditReferencesModule/mark")
                        .param("requestId", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

}
