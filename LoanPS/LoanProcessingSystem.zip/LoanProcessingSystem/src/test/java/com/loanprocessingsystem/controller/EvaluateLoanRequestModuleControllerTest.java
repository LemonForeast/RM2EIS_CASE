package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.enums.CheckingAccountStatus;
import com.loanprocessingsystem.service.EvaluateLoanRequestModule;
import com.loanprocessingsystem.service.SubmitLoanRequestModule;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(EvaluateLoanRequestModuleController.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EvaluateLoanRequestModuleControllerTest {

    private final Long requestId = 1L;
    private final Long requestId2 = 2L;

    @Autowired
    private MockMvc mvc;

    @MockBean
    private EvaluateLoanRequestModule evaluateLoanRequestModule;

    @BeforeAll
    public void setup() {
        LoanRequest loanRequest1 = new LoanRequest();
        LoanRequest loanRequest2 = new LoanRequest();
        loanRequest1.setId(requestId);
        loanRequest2.setId(requestId2);

        Mockito.when(evaluateLoanRequestModule.listTenLoanRequest()).
                thenReturn(List.of(loanRequest1, loanRequest2));

        Mockito.when(evaluateLoanRequestModule.
                chooseOneForReview(requestId)).thenReturn(loanRequest1);

        Mockito.when(evaluateLoanRequestModule.
                checkCreditHistory(requestId)).
                thenReturn(loanRequest1.getRequestedCreditHistory());

        Mockito.when(evaluateLoanRequestModule.
                reviewCheckingAccount(requestId)).
                thenReturn(loanRequest1.getRequestedCAHistory());

        Mockito.when(evaluateLoanRequestModule.
                        listAvaiableLoanTerm()).
                thenReturn(Collections.emptyList());

        Mockito.when(evaluateLoanRequestModule.
                        approveLoanRequest(requestId)).
                thenReturn(true);

    }

    @Test
    void testListTenLoanRequest() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/evaluateLoanRequestModule/list")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testChooseOneForReview() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/evaluateLoanRequestModule/choose")
                        .param("requestId", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testCreateDevice() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/evaluateLoanRequestModule/checkCreditHistory")
                        .param("requestId", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testReviewCheckingAccount() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/evaluateLoanRequestModule/reviewCheckingAccount")
                        .param("requestId", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testListAvaiableLoanTerm() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/evaluateLoanRequestModule/listAvaiableLoanTerm")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testApproveLoanRequest() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/evaluateLoanRequestModule/approveLoanRequest")
                        .param("requestId", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

}
