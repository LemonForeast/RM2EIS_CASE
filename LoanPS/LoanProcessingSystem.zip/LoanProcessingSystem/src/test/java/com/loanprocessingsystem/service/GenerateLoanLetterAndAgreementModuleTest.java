package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.LoanAgreement;
import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.enums.LoanRequestStatus;
import com.loanprocessingsystem.repository.ApprovalLetterRepository;
import com.loanprocessingsystem.repository.LoanAgreementRepository;
import com.loanprocessingsystem.repository.LoanRequestRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class GenerateLoanLetterAndAgreementModuleTest {

    private final Long id = 1L;
    private final Long requestId = 2L;

    private LoanRequest loanRequest;

    private GenerateLoanLetterAndAgreementModule generateLoanLetterAndAgreementModule;
    @MockBean
    private LoanRequestRepository loanRequestRepository;
    @MockBean
    private ApprovalLetterRepository approvalLetterRepository;
    @MockBean
    private LoanAgreementRepository loanAgreementRepository;
    @MockBean
    private ThirdPartyServices thirdPartyServices;


    @BeforeEach
    public void setup() {
        generateLoanLetterAndAgreementModule = new GenerateLoanLetterAndAgreementModule(
                loanRequestRepository, approvalLetterRepository, loanAgreementRepository, thirdPartyServices);

        loanRequest = new LoanRequest();
        loanRequest.setId(requestId);

        Mockito.when(loanRequestRepository.findAllByLoanRequestStatus(LoanRequestStatus.APPROVED)).
                thenReturn(List.of(loanRequest));

        Mockito.when(loanRequestRepository.findById(requestId)).thenReturn(Optional.of(loanRequest));
    }

    @Test
    void testListApprovalRequest_thenGetApprovedLoanRequestList() {
        List<LoanRequest> loanRequestList =
                generateLoanLetterAndAgreementModule.listApprovalRequest();

        assertNotNull(loanRequestList);
    }

    @Test
    void testGenerateApprovalLetter_thenProcessShouldBeSuccessful() {
        boolean result =
                generateLoanLetterAndAgreementModule.generateApprovalLetter(id, requestId);

        assertTrue(result);
    }

    @Test
    void testEmailToAppliant_thenProcessShouldBeSuccessful() {
        boolean result =
                generateLoanLetterAndAgreementModule.emailToAppliant(requestId);

        assertTrue(result);
    }

    @Test
    void testGenerateLoanAgreement_thenProcessShouldBeSuccessful() {
        boolean result =
                generateLoanLetterAndAgreementModule.generateLoanAgreement(id, requestId);

        assertTrue(result);
    }

    @Test
    void testPrintLoanAgreement_thenProcessShouldBeSuccessful() {
        loanRequest.setAttachedLoanAgreement(new LoanAgreement(1L, "content"));
        boolean result =
                generateLoanLetterAndAgreementModule.printLoanAgreement(requestId, 4);

        assertTrue(result);
    }

}
