package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.model.enums.CheckingAccountStatus;
import com.loanprocessingsystem.service.SubmitLoanRequestModule;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(SubmitLoanRequestModuleController.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class SubmitLoanRequestModuleControllerTest {

    private final Long requestId = 1L;
    private final Long creditRequestId = 1L;
    private final Long accountStatusRequestId = 1L;

    private String name = "ragcrix";
    private double loanAmount = 12500;
    private String loanPurpose = "For family";
    private Double income = 1000D;
    private int phoneNumber = 123456;
    private String postalAddress = "123456";
    private int zipCode = 123456;
    private String email = "ragcrix@r.com";
    private String workReferences = "bla bla";
    private String creditReferences = "bla bla";
    private int checkingAccountNumber = 4;
    private int securityNumber = 6;

    private double outstandingDebits = 5;
    private int badDebits = 3;

    private double balance = 1240;

    @Autowired
    private MockMvc mvc;

    @MockBean
    private SubmitLoanRequestModule submitLoanRequestModule;

    @BeforeAll
    public void setup() {
        Mockito.when(submitLoanRequestModule.enterLoanInformation(
                requestId, name, loanAmount, loanPurpose, income, phoneNumber, postalAddress, zipCode,
                email, workReferences, creditReferences, checkingAccountNumber, securityNumber)).thenReturn(true);

        Mockito.when(submitLoanRequestModule.creditRequest(creditRequestId,
                outstandingDebits, badDebits, securityNumber, name)).thenReturn(true);

        Mockito.when(submitLoanRequestModule.
                accountStatusRequest(accountStatusRequestId, balance,
                        CheckingAccountStatus.GOODSTANDING, 4)).thenReturn(true);

        Mockito.when(submitLoanRequestModule.calculateScore(requestId)).thenReturn(100);

    }

    @Test
    void testEnterLoanInformation() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/submitLoanRequest/enterLoanInformation")
                        .param("requestId", String.valueOf(requestId))
                        .param("name", name)
                        .param("loanAmount", String.valueOf(loanAmount))
                        .param("loanPurpose", loanPurpose)
                        .param("income", String.valueOf(income))
                        .param("phoneNumber", String.valueOf(phoneNumber))
                        .param("postalAddress", postalAddress)
                        .param("zipCode", String.valueOf(zipCode))
                        .param("email", email)
                        .param("workReferences", workReferences)
                        .param("creditReferences", creditReferences)
                        .param("checkingAccountNumber", String.valueOf(checkingAccountNumber))
                        .param("securityNumber", String.valueOf(securityNumber))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testCreditRequest() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/submitLoanRequest/creditRequest")
                        .param("id", String.valueOf(creditRequestId))
                        .param("outstandingDebits", String.valueOf(outstandingDebits))
                        .param("badDebits", String.valueOf(badDebits))
                        .param("securityNumber", String.valueOf(securityNumber))
                        .param("name", name)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testAccountStatusRequest() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/submitLoanRequest/accountStatusRequest")
                        .param("id", String.valueOf(accountStatusRequestId))
                        .param("balance", String.valueOf(balance))
                        .param("checkingAccountStatus", CheckingAccountStatus.GOODSTANDING.name())
                        .param("checkingAccountNumber", String.valueOf(4))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testCalculateScore() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/submitLoanRequest/calculateScore")
                        .param("id", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

}
