package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.service.LoanProcessingSystem;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(LoanProcessingSystemController.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class LoanProcessingSystemControllerTest {

    private final Long requestId = 1L;

    private final Long loanId = 1L;

    private final Long accountId = 1L;

    private final LocalDate startDate = LocalDate.now();

    private final LocalDate endDate = LocalDate.now();

    private final int repaymetDays = 5;

    @Autowired
    private MockMvc mvc;
    @MockBean
    private LoanProcessingSystem loanProcessingSystem;

    @BeforeAll
    public void setup() {
        Mockito.when(loanProcessingSystem.bookNewLoan(
                requestId, loanId, accountId, startDate, endDate, repaymetDays)).thenReturn(true);
        Mockito.when(loanProcessingSystem.generateStandardPaymentNotice()).thenReturn(true);

        Mockito.when(loanProcessingSystem.generateLateNotice(requestId)).thenReturn(true);

        Mockito.when(loanProcessingSystem.loanPayment(loanId)).thenReturn(true);

        Mockito.when(loanProcessingSystem.closeOutLoan(loanId)).thenReturn(true);
    }

    @Test
    void testBookNewLoan() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/loanProcessingSystem/bookNewLoan")
                        .param("requestId", String.valueOf(requestId))
                        .param("loanId", String.valueOf(loanId))
                        .param("accountId", String.valueOf(accountId))
                        .param("startDate", String.valueOf(startDate))
                        .param("endDate", String.valueOf(endDate))
                        .param("repaymentDays", String.valueOf(repaymetDays))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testGenerateStandardPaymentNotice() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/loanProcessingSystem/generateStandardPaymentNotice")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testGenerateLateNotice() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/loanProcessingSystem/generateLateNotice")
                        .param("requestId", String.valueOf(requestId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testLoanPayment() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/loanProcessingSystem/loanPayment")
                        .param("loanId", String.valueOf(loanId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testCloseOutLoan() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/loanProcessingSystem/closeOutLoan")
                        .param("loanId", String.valueOf(loanId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }
    
}
