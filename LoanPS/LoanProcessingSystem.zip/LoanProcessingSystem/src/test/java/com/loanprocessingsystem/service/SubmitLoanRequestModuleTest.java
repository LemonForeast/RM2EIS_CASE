package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.CheckingAccount;
import com.loanprocessingsystem.model.entity.CreditHistory;
import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.enums.CheckingAccountStatus;
import com.loanprocessingsystem.repository.CheckingAccountRepository;
import com.loanprocessingsystem.repository.CreditHistoryRepository;
import com.loanprocessingsystem.repository.LoanRequestRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class SubmitLoanRequestModuleTest {

    private final Long requestId = 1L;
    private final Long accountStatusRequestId = 1L;

    private String name = "ragcrix";
    private double loanAmount = 12500;
    private String loanPurpose = "For family";
    private Double income = 1000D;
    private int phoneNumber = 123456;
    private String postalAddress = "123456";
    private int zipCode = 123456;
    private String email = "ragcrix@r.com";
    private String workReferences = "bla bla";
    private String creditReferences = "bla bla";
    private int checkingAccountNumber = 4;
    private int securityNumber = 6;

    private double outstandingDebits = 5;
    private int badDebits = 3;

    private double balance = 1240;

    private LoanRequest loanRequest;

    private SubmitLoanRequestModule submitLoanRequestModule;
    @MockBean
    private LoanRequestRepository loanRequestRepository;
    @MockBean
    private CreditHistoryRepository creditHistoryRepository;
    @MockBean
    private CheckingAccountRepository checkingAccountRepository;

    @BeforeEach
    public void setup() {
        submitLoanRequestModule = new SubmitLoanRequestModule(loanRequestRepository, creditHistoryRepository, checkingAccountRepository);

        loanRequest = new LoanRequest();
        loanRequest.setId(requestId);

        Mockito.when(loanRequestRepository.findById(requestId)).thenReturn(Optional.of(loanRequest));

        Mockito.when(loanRequestRepository.findLoanRequestBySecurityNumberAndName(securityNumber, name)).
                thenReturn(Optional.of(loanRequest));

        Mockito.when(loanRequestRepository.findLoanRequestByCheckingAccountNumber(checkingAccountNumber)).
                thenReturn(Optional.of(loanRequest));
    }

    @Test
    void testEnterLoanInformation_thenProcessShouldBeSuccessful() {
        Mockito.when(loanRequestRepository.findById(2L)).thenReturn(Optional.empty());

        boolean result = submitLoanRequestModule.enterLoanInformation(
                2L, name, loanAmount, loanPurpose, income, phoneNumber, postalAddress, zipCode,
                email, workReferences, creditReferences, checkingAccountNumber, securityNumber);

        assertTrue(result);
    }

    @Test
    void testCreditRequest_thenProcessShouldBeSuccessful() {
        boolean result =
                submitLoanRequestModule.
                        accountStatusRequest(accountStatusRequestId, balance,
                                CheckingAccountStatus.GOODSTANDING, 4);

        assertTrue(result);
    }

    @Test
    void testCalculateScore_thenProcessShouldBeSuccessful() {
        loanRequest.setRequestedCAHistory(new CheckingAccount());
        loanRequest.setRequestedCreditHistory(new CreditHistory());
        int result =
                submitLoanRequestModule.calculateScore(requestId);

        assertEquals(100, result);
    }

}
