package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.enums.LoanRequestStatus;
import com.loanprocessingsystem.repository.LoanRequestRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EnterValidatedCreditReferenceModuleTest {

    private final Long requestId = 1L;

    private EnterValidatedCreditReferencesModule enterValidatedCreditReferencesModule;
    @MockBean
    private LoanRequestRepository loanRequestRepository;

    @BeforeEach
    public void setup() {
        enterValidatedCreditReferencesModule = new EnterValidatedCreditReferencesModule(loanRequestRepository);
        LoanRequest loanRequest = new LoanRequest();
        loanRequest.setId(requestId);

        Mockito.when(loanRequestRepository.findAllByLoanRequestStatus(LoanRequestStatus.SUBMITTED)).
                thenReturn(List.of(loanRequest));

        Mockito.when(loanRequestRepository.findById(requestId)).thenReturn(Optional.of(loanRequest));
    }

    @Test
    void testListSubmitedLoanRequest_thenGetLoanRequestList() {
        List<LoanRequest> loanRequestList =
                enterValidatedCreditReferencesModule.listSubmitedLoanRequest();

        assertNotNull(loanRequestList);
    }

    @Test
    void testChooseLoanRequest_thenGetLoanRequest() {
        LoanRequest loanRequest =
                enterValidatedCreditReferencesModule.chooseLoanRequest(requestId);

        assertNotNull(loanRequest);
    }

    @Test
    void testMarkRequestValid_thenProcessShouldBeSuccessful() {
        boolean result =
                enterValidatedCreditReferencesModule.markRequestValid(requestId);

        assertTrue(result);
    }

}
