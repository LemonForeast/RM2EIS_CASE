package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.enums.LoanRequestStatus;
import com.loanprocessingsystem.repository.LoanRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EnterValidatedCreditReferencesModule {

    private LoanRequestRepository loanRequestRepository;

    @Autowired
    public EnterValidatedCreditReferencesModule(LoanRequestRepository loanRequestRepository) {
        this.loanRequestRepository = loanRequestRepository;
    }

    public List<LoanRequest> listSubmitedLoanRequest() {
        return loanRequestRepository.findAllByLoanRequestStatus(LoanRequestStatus.SUBMITTED);
    }

    public LoanRequest chooseLoanRequest(Long requestId) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        LoanRequest loanRequest = null;
        if (optionalLoanRequest.isPresent()) {
            loanRequest = optionalLoanRequest.get();
        }
        return loanRequest;
    }

    public boolean markRequestValid(Long requestId) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        boolean result = false;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();
            loanRequest.setLoanRequestStatus(LoanRequestStatus.REFERENCES_VALIDATED);
            loanRequestRepository.save(loanRequest);
            result = true;
        }
        return result;
    }
}
