package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.controller.generic.GenericController;
import com.loanprocessingsystem.controller.generic.response.GenericResponse;
import com.loanprocessingsystem.service.ManageLoanTermCRUDService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/manageLoanTerm",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class ManageLoanTermController extends GenericController {

    private final ManageLoanTermCRUDService manageLoanTermCRUDService;

    @Autowired
    public ManageLoanTermController(ManageLoanTermCRUDService manageLoanTermCRUDService) {
        this.manageLoanTermCRUDService = manageLoanTermCRUDService;
    }

    @PostMapping("/createLoanTerm")
    public @ResponseBody
    GenericResponse createLoanTerm(@RequestParam Long loanTermId, @RequestParam String content) {
        return createSuccessResponse(manageLoanTermCRUDService.createLoanTerm(loanTermId, content));
    }

    @GetMapping("/queryLoanTerm")
    public @ResponseBody
    GenericResponse queryLoanTerm(@RequestParam Long loanTermId) {
        return createSuccessResponse(manageLoanTermCRUDService.queryLoanTerm(loanTermId));
    }

    @PostMapping("/modifyLoanTerm")
    public @ResponseBody
    GenericResponse modifyLoanTerm(@RequestParam Long loanTermId, @RequestParam Long newId,
                                   @RequestParam String content) {
        return createSuccessResponse(manageLoanTermCRUDService.modifyLoanTerm(loanTermId, newId, content));
    }

    @PostMapping("/deleteLoanTerm")
    public @ResponseBody
    GenericResponse deleteLoanTerm(@RequestParam Long loanTermId) {
        return createSuccessResponse(manageLoanTermCRUDService.deleteLoanTerm(loanTermId));
    }

}
