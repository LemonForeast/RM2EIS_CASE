package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.Loan;
import com.loanprocessingsystem.model.entity.LoanAccount;
import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.enums.LoanStatus;
import com.loanprocessingsystem.repository.LoanAccountRepository;
import com.loanprocessingsystem.repository.LoanRepository;
import com.loanprocessingsystem.repository.LoanRequestRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class LoanProcessingSystem {

    private LoanRequestRepository loanRequestRepository;
    private LoanAccountRepository loanAccountRepository;
    private LoanRepository loanRepository;
    private ThirdPartyServices thirdPartyServices;

    @Autowired
    public LoanProcessingSystem(LoanRequestRepository loanRequestRepository,
                                LoanAccountRepository loanAccountRepository,
                                LoanRepository loanRepository,
                                ThirdPartyServices thirdPartyServices) {
        this.loanRequestRepository = loanRequestRepository;
        this.loanAccountRepository = loanAccountRepository;
        this.loanRepository = loanRepository;
        this.thirdPartyServices = thirdPartyServices;
    }

    public boolean bookNewLoan(Long requestId, Long loanId, Long accountId,
                               LocalDate startDate, LocalDate endDate, int repaymentDays) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        Optional<LoanAccount> optionalLoanAccount = loanAccountRepository.findById(accountId);
        LoanAccount loanAccount;
        boolean result = false;

        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();

            Loan loan = new Loan();
            loan.setId(loanId);
            loan.setStartDate(startDate);
            loan.setEndDate(endDate);
            loan.setRepaymentDays(repaymentDays);
            loan.setStatus(LoanStatus.LSOPEN);
            loan.setRepaymentAmount(loanRequest.getLoanAmount());
            loan.setCurrentOverDueDate(startDate.plusDays(repaymentDays));

            if (optionalLoanAccount.isEmpty()) {
                //createLoanAccount
                loanAccount = new LoanAccount();
                loanAccount.setBalance(loanRequest.getLoanAmount());

                loan.setBelongedLoanAccount(loanAccount);
            } else {
                loanAccount = optionalLoanAccount.get();
                loanAccount.setBalance(loanAccount.getBalance() + loanRequest.getLoanAmount());
            }

            thirdPartyServices.transferFunds(loanAccount.getId(), loanAccount.getBalance());
            loan.setRemainAmountToPay(loanRequest.getLoanAmount());

            loan.setReferedLoanRequest(loanRequest);
            loanRequest.setApprovalLoan(loan);

            loanRepository.save(loan);
            loanAccountRepository.save(loanAccount);
            loanRequestRepository.save(loanRequest);

            result = true;
        }
        return result;
    }

    public boolean generateStandardPaymentNotice() {
        List<Loan> loanList = loanRepository.
                findAllByStatusAndCurrentOverDueDateLessThan(
                        LoanStatus.LSOPEN, LocalDate.now().plusDays(3));
        for (Loan loan : loanList) {
            thirdPartyServices.sendEmail(loan.getReferedLoanRequest().getEmail(), "OverDueSoon", "You account is OverDueSoon");
        }
        return true;
    }

    public boolean generateLateNotice(Long requestId) {
        List<Loan> loanList = loanRepository.
                findAllByStatusAndCurrentOverDueDateLessThan(LoanStatus.LSOPEN, LocalDate.now());
        for (Loan loan : loanList) {
            thirdPartyServices.sendEmail(loan.getReferedLoanRequest().getEmail(), "OverDued", "You are overdued, please repayment ASAP");
        }
        return true;
    }

    public boolean loanPayment(Long loanId) {
        Optional<Loan> optionalLoan = loanRepository.findById(loanId);
        boolean result = false;
        if (optionalLoan.isPresent()) {
            Loan loan = optionalLoan.get();
            if (loan.getStatus() == LoanStatus.LSOPEN) {
                loan.setRemainAmountToPay(loan.getRemainAmountToPay() - loan.getRepaymentAmount());
                result = true;
            }
        }
        return result;
    }

    public boolean closeOutLoan(Long loanId) {
        Optional<Loan> optionalLoan = loanRepository.findById(loanId);
        boolean result = false;
        if (optionalLoan.isPresent()) {
            Loan loan = optionalLoan.get();
            if (loan.getStatus() == LoanStatus.LSOPEN) {
                loan.setStatus(LoanStatus.CLOSED);
                result = true;
            }
        }
        return result;
    }

}
