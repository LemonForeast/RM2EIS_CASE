package com.loanprocessingsystem.repository;

import com.loanprocessingsystem.model.entity.LoanTerm;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoanTermRepository extends JpaRepository<LoanTerm, Long> {

    List<LoanTerm> findAll();

    LoanTerm save(LoanTerm loanTerm);

    void delete(LoanTerm loanTerm);
}