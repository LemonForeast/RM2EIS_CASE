package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.ApprovalLetter;
import com.loanprocessingsystem.model.entity.LoanAgreement;
import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.enums.LoanRequestStatus;
import com.loanprocessingsystem.repository.ApprovalLetterRepository;
import com.loanprocessingsystem.repository.LoanAgreementRepository;
import com.loanprocessingsystem.repository.LoanRequestRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class GenerateLoanLetterAndAgreementModule {

    private LoanRequestRepository loanRequestRepository;
    private ApprovalLetterRepository approvalLetterRepository;
    private LoanAgreementRepository loanAgreementRepository;
    private ThirdPartyServices thirdPartyServices;

    @Autowired
    public GenerateLoanLetterAndAgreementModule(LoanRequestRepository loanRequestRepository,
                                                ApprovalLetterRepository approvalLetterRepository,
                                                LoanAgreementRepository loanAgreementRepository,
                                                ThirdPartyServices thirdPartyServices) {
        this.loanRequestRepository = loanRequestRepository;
        this.approvalLetterRepository = approvalLetterRepository;
        this.loanAgreementRepository = loanAgreementRepository;
        this.thirdPartyServices = thirdPartyServices;
    }

    public List<LoanRequest> listApprovalRequest() {
        return loanRequestRepository.findAllByLoanRequestStatus(LoanRequestStatus.APPROVED);
    }

    public boolean generateApprovalLetter(Long id, Long requestId) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        boolean result = false;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();

            ApprovalLetter approvalLetter = new ApprovalLetter(id, "ApprovalLetterContent");
            loanRequest.setAttachedApprovalLetter(approvalLetter);

            approvalLetterRepository.save(approvalLetter);
            loanRequestRepository.save(loanRequest);

            result = true;
        }
        return result;
    }

    public boolean emailToAppliant(Long requestId) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        boolean result = false;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();
            thirdPartyServices.sendEmail(loanRequest.getEmail(), loanRequest.getName(), "Your Loan Request was approved");

            result = true;
        }
        return result;
    }

    public boolean generateLoanAgreement(Long id, Long requestId) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        boolean result = false;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();
            LoanAgreement loanAgreement = new LoanAgreement(id, "Loan Agreement");

            loanRequest.setAttachedLoanAgreement(loanAgreement);

            loanAgreementRepository.save(loanAgreement);
            loanRequestRepository.save(loanRequest);

            result = true;
        }
        return result;
    }

    public boolean printLoanAgreement(Long requestId, int number) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        boolean result = false;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();

            thirdPartyServices.print(loanRequest.getAttachedLoanAgreement().getContent(), number);

            result = true;
        }
        return result;
    }

}
