package com.loanprocessingsystem.repository;

import com.loanprocessingsystem.model.entity.ApprovalLetter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApprovalLetterRepository extends JpaRepository<ApprovalLetter, Long> {

    ApprovalLetter save(ApprovalLetter approvalLetter);

    void delete(ApprovalLetter approvalLetter);
}