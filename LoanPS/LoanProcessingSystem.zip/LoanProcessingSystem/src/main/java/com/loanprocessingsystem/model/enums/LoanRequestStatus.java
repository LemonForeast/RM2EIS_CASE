package com.loanprocessingsystem.model.enums;

public enum LoanRequestStatus {
    SUBMITTED, REFERENCES_VALIDATED, APPROVED, READY_FOR_PREVIEW, INCOMPLETE_INFORMATION;
}
