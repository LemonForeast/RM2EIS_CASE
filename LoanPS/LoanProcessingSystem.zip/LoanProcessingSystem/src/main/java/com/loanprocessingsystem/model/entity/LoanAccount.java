package com.loanprocessingsystem.model.entity;

import com.loanprocessingsystem.model.enums.LoanAccountStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class LoanAccount {
    @Id
    private Long id;
    private double balance;
    @Enumerated(EnumType.STRING)
    private LoanAccountStatus loanAccountStatus;
}
