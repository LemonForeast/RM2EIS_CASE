package com.loanprocessingsystem.model.entity;

import com.loanprocessingsystem.model.enums.CheckingAccountStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class CheckingAccount {
    @Id
    private Long id;
    private double balance;
    @Enumerated(EnumType.STRING)
    private CheckingAccountStatus checkingAccountStatus;
}
