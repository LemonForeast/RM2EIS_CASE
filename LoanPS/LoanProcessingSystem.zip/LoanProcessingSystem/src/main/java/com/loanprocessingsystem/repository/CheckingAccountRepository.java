package com.loanprocessingsystem.repository;

import com.loanprocessingsystem.model.entity.CheckingAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CheckingAccountRepository extends JpaRepository<CheckingAccount, Long> {
    Optional<CheckingAccount> findById(Long id);

    List<CheckingAccount> findAll();

    CheckingAccount save(CheckingAccount checkingAccount);

    void delete(CheckingAccount checkingAccount);
}