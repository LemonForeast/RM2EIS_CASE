package com.loanprocessingsystem.model.entity;

import com.loanprocessingsystem.model.enums.LoanRequestStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class LoanRequest {
    @Id
    private Long id;
    @Enumerated(EnumType.STRING)
    private LoanRequestStatus loanRequestStatus;
    private String name;
    private double loanAmount;
    private String loanPurpose;
    private double income;
    private int phoneNumber;
    private String postalAddress;
    private int zipCode;
    private String email;
    private String workReferences;
    private String creditReferences;
    private int checkingAccountNumber;
    private int securityNumber;
    private int creditScore;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Loan approvalLoan;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private CheckingAccount requestedCAHistory;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private CreditHistory requestedCreditHistory;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private ApprovalLetter attachedApprovalLetter;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private LoanAgreement attachedLoanAgreement;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<LoanTerm> attachedLoanTerms;

}
