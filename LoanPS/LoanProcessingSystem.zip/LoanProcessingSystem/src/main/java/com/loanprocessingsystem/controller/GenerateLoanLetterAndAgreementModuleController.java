package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.controller.generic.GenericController;
import com.loanprocessingsystem.controller.generic.response.GenericResponse;
import com.loanprocessingsystem.service.GenerateLoanLetterAndAgreementModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/generateLoanLetterAndAgreementModule",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class GenerateLoanLetterAndAgreementModuleController extends GenericController {

    private final GenerateLoanLetterAndAgreementModule generateLoanLetterAndAgreementModule;

    @Autowired
    public GenerateLoanLetterAndAgreementModuleController(GenerateLoanLetterAndAgreementModule generateLoanLetterAndAgreementModule) {
        this.generateLoanLetterAndAgreementModule = generateLoanLetterAndAgreementModule;
    }

    @GetMapping("/listApprovalRequest")
    public @ResponseBody
    GenericResponse listApprovalRequest() {
        return createSuccessResponse(generateLoanLetterAndAgreementModule.listApprovalRequest());
    }

    @PostMapping("/generateApprovalLetter")
    public @ResponseBody
    GenericResponse generateApprovalLetter(@RequestParam Long id, @RequestParam Long requestId) {
        return createSuccessResponse(generateLoanLetterAndAgreementModule.generateApprovalLetter(id, requestId));
    }

    @PostMapping("/emailToAppliant")
    public @ResponseBody
    GenericResponse emailToAppliant(@RequestParam Long requestId) {
        return createSuccessResponse(generateLoanLetterAndAgreementModule.emailToAppliant(requestId));
    }

    @PostMapping("/generateLoanAgreement")
    public @ResponseBody
    GenericResponse generateLoanAgreement(@RequestParam Long id, @RequestParam Long requestId) {
        return createSuccessResponse(generateLoanLetterAndAgreementModule.generateLoanAgreement(id, requestId));
    }

    @PostMapping("/printLoanAgreement")
    public @ResponseBody
    GenericResponse printLoanAgreement(@RequestParam Long requestId, @RequestParam int number) {
        return createSuccessResponse(generateLoanLetterAndAgreementModule.printLoanAgreement(requestId, number));
    }

}
