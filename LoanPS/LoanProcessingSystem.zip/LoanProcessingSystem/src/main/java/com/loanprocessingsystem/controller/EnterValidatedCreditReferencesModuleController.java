package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.controller.generic.GenericController;
import com.loanprocessingsystem.controller.generic.response.GenericResponse;
import com.loanprocessingsystem.service.EnterValidatedCreditReferencesModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/validatedCreditReferencesModule",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class EnterValidatedCreditReferencesModuleController extends GenericController {

    private final EnterValidatedCreditReferencesModule enterValidatedCreditReferencesModule;

    @Autowired
    public EnterValidatedCreditReferencesModuleController(EnterValidatedCreditReferencesModule enterValidatedCreditReferencesModule) {
        this.enterValidatedCreditReferencesModule = enterValidatedCreditReferencesModule;
    }

    @GetMapping("/list")
    public @ResponseBody
    GenericResponse listSubmitedLoanRequest() {
        return createSuccessResponse(enterValidatedCreditReferencesModule.listSubmitedLoanRequest());
    }

    @GetMapping("/choose")
    public @ResponseBody
    GenericResponse chooseLoanRequest(@RequestParam Long requestId) {
        return createSuccessResponse(enterValidatedCreditReferencesModule.chooseLoanRequest(requestId));
    }

    @PostMapping("/mark")
    public @ResponseBody
    GenericResponse createDevice(@RequestParam Long requestId) {
        return createSuccessResponse(enterValidatedCreditReferencesModule.markRequestValid(requestId));
    }
}
