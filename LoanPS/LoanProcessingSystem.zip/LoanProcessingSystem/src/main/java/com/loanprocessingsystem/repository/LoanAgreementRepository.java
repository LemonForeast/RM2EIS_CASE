package com.loanprocessingsystem.repository;

import com.loanprocessingsystem.model.entity.LoanAgreement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoanAgreementRepository extends JpaRepository<LoanAgreement, Long> {

    List<LoanAgreement> findAll();

    LoanAgreement save(LoanAgreement loanAgreement);

    void delete(LoanAgreement loanAgreement);
}