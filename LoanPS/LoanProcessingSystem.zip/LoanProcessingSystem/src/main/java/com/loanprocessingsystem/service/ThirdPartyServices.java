package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.CheckingAccount;
import com.loanprocessingsystem.model.entity.CreditHistory;
import com.loanprocessingsystem.model.entity.LoanAccount;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
public class ThirdPartyServices {

    public CheckingAccount getCheckingAccountStatus(Long cid) {
        return null;
    }

    public CreditHistory getCreditHistory(Long securityId, String name) {
        return null;
    }

    public boolean sendEmail(String emailAddress, String title, String content) {
        return true;
    }

    public boolean print(String content, int numbers) {
        return true;
    }

    public LoanAccount createLoanAccount(Long id) {
        return null;
    }

    public boolean transferFunds(Long id, double amount) {
        return true;
    }

    public boolean listBookedLoans() {
        return true;
    }

}
