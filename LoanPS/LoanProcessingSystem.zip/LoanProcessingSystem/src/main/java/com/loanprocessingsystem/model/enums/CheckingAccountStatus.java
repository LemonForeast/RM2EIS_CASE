package com.loanprocessingsystem.model.enums;

public enum CheckingAccountStatus {
    GOODSTANDING, SUSPENDED;
}
