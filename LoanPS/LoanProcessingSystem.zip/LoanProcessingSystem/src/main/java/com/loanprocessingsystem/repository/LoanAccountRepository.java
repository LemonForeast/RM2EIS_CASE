package com.loanprocessingsystem.repository;

import com.loanprocessingsystem.model.entity.LoanAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LoanAccountRepository extends JpaRepository<LoanAccount, Long> {
    Optional<LoanAccount> findById(Long id);

    List<LoanAccount> findAll();

    LoanAccount save(LoanAccount loanAccount);

    void delete(LoanAccount loanAccount);
}