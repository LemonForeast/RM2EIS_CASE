package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.CheckingAccount;
import com.loanprocessingsystem.model.entity.CreditHistory;
import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.entity.LoanTerm;
import com.loanprocessingsystem.model.enums.LoanRequestStatus;
import com.loanprocessingsystem.repository.LoanRequestRepository;
import com.loanprocessingsystem.repository.LoanTermRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EvaluateLoanRequestModule {

    private LoanRequestRepository loanRequestRepository;
    private LoanTermRepository loanTermRepository;

    @Autowired
    public EvaluateLoanRequestModule(LoanRequestRepository loanRequestRepository,
                                     LoanTermRepository loanTermRepository) {
        this.loanRequestRepository = loanRequestRepository;
        this.loanTermRepository = loanTermRepository;
    }

    public List<LoanRequest> listTenLoanRequest() {
        return loanRequestRepository.findAllByLoanRequestStatus(LoanRequestStatus.REFERENCES_VALIDATED);
    }

    public LoanRequest chooseOneForReview(Long requestId) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        LoanRequest loanRequest = null;
        if (optionalLoanRequest.isPresent()) {
            loanRequest = optionalLoanRequest.get();
        }
        return loanRequest;
    }

    public CreditHistory checkCreditHistory(Long requestId) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        CreditHistory creditHistory = null;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();
            creditHistory = loanRequest.getRequestedCreditHistory();
        }
        return creditHistory;
    }

    public CheckingAccount reviewCheckingAccount(Long requestId) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        CheckingAccount checkingAccount = null;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();
            checkingAccount = loanRequest.getRequestedCAHistory();
        }
        return checkingAccount;
    }

    public List<LoanTerm> listAvaiableLoanTerm() {
        return loanTermRepository.findAll();
    }

    public boolean addLoanTerm(Long termId, Long requestId) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        boolean result = false;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();

            LoanTerm loanTerm = new LoanTerm();
            loanTerm.setId(termId);

            loanRequest.setAttachedLoanTerms(List.of(loanTerm));

            loanTermRepository.save(loanTerm);
            loanRequestRepository.save(loanRequest);

            result = true;
        }
        return result;
    }

    public boolean approveLoanRequest(Long requestId) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        boolean result = false;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();
            loanRequest.setLoanRequestStatus(LoanRequestStatus.APPROVED);

            loanRequestRepository.save(loanRequest);

            result = true;
        }
        return result;
    }
}
