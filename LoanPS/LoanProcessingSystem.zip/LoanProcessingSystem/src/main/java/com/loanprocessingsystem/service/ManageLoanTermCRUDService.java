package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.LoanTerm;
import com.loanprocessingsystem.repository.LoanTermRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
public class ManageLoanTermCRUDService {

    private LoanTermRepository loanTermRepository;

    @Autowired
    public ManageLoanTermCRUDService(LoanTermRepository loanTermRepository) {
        this.loanTermRepository = loanTermRepository;
    }

    public boolean createLoanTerm(Long loanTermId, String content) {
        Optional<LoanTerm> optionalLoanTerm = loanTermRepository.findById(loanTermId);
        boolean result = false;
        if (optionalLoanTerm.isEmpty()) {
            LoanTerm loanTerm = new LoanTerm(loanTermId, content);

            loanTermRepository.save(loanTerm);
            result = true;
        }

        return result;
    }

    public LoanTerm queryLoanTerm(Long loanTermId) {
        return loanTermRepository.findById(loanTermId).get();
    }

    public boolean modifyLoanTerm(Long loanTermId, Long newId, String content) {
        Optional<LoanTerm> optionalLoanTerm = loanTermRepository.findById(loanTermId);
        boolean result = false;
        if (optionalLoanTerm.isPresent()) {
            LoanTerm loanTerm = optionalLoanTerm.get();
            loanTerm.setId(newId);
            loanTerm.setContent(content);
            result = true;
        }
        return result;
    }

    public boolean deleteLoanTerm(Long loanTermId) {
        loanTermRepository.deleteById(loanTermId);
        return true;
    }

}
