package com.loanprocessingsystem.model.enums;

public enum LoanAccountStatus {
    NORMAL, HASPAIDINFUL;
}
