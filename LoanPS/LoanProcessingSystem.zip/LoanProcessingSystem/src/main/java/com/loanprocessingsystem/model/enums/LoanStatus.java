package com.loanprocessingsystem.model.enums;

public enum LoanStatus {
    LSOPEN, CLOSED;
}
