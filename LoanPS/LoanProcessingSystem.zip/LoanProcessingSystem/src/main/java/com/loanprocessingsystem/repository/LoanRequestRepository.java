package com.loanprocessingsystem.repository;

import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.enums.LoanRequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LoanRequestRepository extends JpaRepository<LoanRequest, Long> {
    Optional<LoanRequest> findById(Long id);

    Optional<LoanRequest> findLoanRequestBySecurityNumberAndName(int securityNumber, String name);

    Optional<LoanRequest> findLoanRequestByCheckingAccountNumber(int checkingAccountNumber);

    List<LoanRequest> findAllByLoanRequestStatus(LoanRequestStatus loanRequestStatus);

    List<LoanRequest> findAll();

    LoanRequest save(LoanRequest loanRequest);

    void delete(LoanRequest loanRequest);
}