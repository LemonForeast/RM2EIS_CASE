package com.loanprocessingsystem.repository;

import com.loanprocessingsystem.model.entity.CreditHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CreditHistoryRepository extends JpaRepository<CreditHistory, Long> {
    Optional<CreditHistory> findById(Long id);

    List<CreditHistory> findAll();

    CreditHistory save(CreditHistory creditHistory);

    void delete(CreditHistory creditHistory);
}