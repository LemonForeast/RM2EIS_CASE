package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.controller.generic.GenericController;
import com.loanprocessingsystem.controller.generic.response.GenericResponse;
import com.loanprocessingsystem.model.enums.CheckingAccountStatus;
import com.loanprocessingsystem.service.SubmitLoanRequestModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/submitLoanRequest",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class SubmitLoanRequestModuleController extends GenericController {

    private final SubmitLoanRequestModule submitLoanRequestModule;

    @Autowired
    public SubmitLoanRequestModuleController(SubmitLoanRequestModule submitLoanRequestModule) {
        this.submitLoanRequestModule = submitLoanRequestModule;
    }

    @PostMapping("/enterLoanInformation")
    public @ResponseBody
    GenericResponse enterLoanInformation(@RequestParam Long requestId, @RequestParam String name,
                                         @RequestParam double loanAmount, @RequestParam String loanPurpose,
                                         @RequestParam Double income,
                                         @RequestParam int phoneNumber, @RequestParam String postalAddress,
                                         @RequestParam int zipCode, @RequestParam String email,
                                         @RequestParam String workReferences, @RequestParam String creditReferences,
                                         @RequestParam int checkingAccountNumber, @RequestParam int securityNumber) {
        return createSuccessResponse(submitLoanRequestModule.
                enterLoanInformation(requestId, name, loanAmount, loanPurpose, income, phoneNumber,
                        postalAddress, zipCode, email, workReferences, creditReferences, checkingAccountNumber, securityNumber));
    }

    @GetMapping("/creditRequest")
    public @ResponseBody
    GenericResponse creditRequest(@RequestParam Long id, @RequestParam double outstandingDebits, @RequestParam int badDebits,
                                  @RequestParam int securityNumber, @RequestParam String name) {
        return createSuccessResponse(submitLoanRequestModule.
                creditRequest(id, outstandingDebits, badDebits, securityNumber, name));
    }

    @PostMapping("/accountStatusRequest")
    public @ResponseBody
    GenericResponse accountStatusRequest(@RequestParam Long id, @RequestParam double balance,
                                         @RequestParam CheckingAccountStatus checkingAccountStatus,
                                         @RequestParam int checkingAccountNumber) {
        return createSuccessResponse(submitLoanRequestModule.
                accountStatusRequest(id, balance, checkingAccountStatus, checkingAccountNumber));
    }

    @PostMapping("/calculateScore")
    public @ResponseBody
    GenericResponse calculateScore(@RequestParam Long id) {
        return createSuccessResponse(submitLoanRequestModule.calculateScore(id));
    }

}
