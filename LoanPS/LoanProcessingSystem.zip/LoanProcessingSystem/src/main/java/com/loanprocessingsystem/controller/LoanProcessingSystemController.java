package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.controller.generic.GenericController;
import com.loanprocessingsystem.controller.generic.response.GenericResponse;
import com.loanprocessingsystem.service.LoanProcessingSystem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping(value = "/loanProcessingSystem",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class LoanProcessingSystemController extends GenericController {

    private final LoanProcessingSystem loanProcessingSystem;

    @Autowired
    public LoanProcessingSystemController(LoanProcessingSystem loanProcessingSystem) {
        this.loanProcessingSystem = loanProcessingSystem;
    }

    @PostMapping("/bookNewLoan")
    public @ResponseBody
    GenericResponse bookNewLoan(@RequestParam Long requestId, @RequestParam Long loanId,
                                @RequestParam Long accountId, @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                                @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
                                @RequestParam int repaymentDays) {
        return createSuccessResponse(loanProcessingSystem.
                bookNewLoan(requestId, loanId, accountId, startDate, endDate, repaymentDays));
    }

    @PostMapping("/generateStandardPaymentNotice")
    public @ResponseBody
    GenericResponse generateStandardPaymentNotice() {
        return createSuccessResponse(loanProcessingSystem.generateStandardPaymentNotice());
    }

    @PostMapping("/generateLateNotice")
    public @ResponseBody
    GenericResponse generateLateNotice(@RequestParam Long requestId) {
        return createSuccessResponse(loanProcessingSystem.generateLateNotice(requestId));
    }

    @PostMapping("/loanPayment")
    public @ResponseBody
    GenericResponse loanPayment(@RequestParam Long loanId) {
        return createSuccessResponse(loanProcessingSystem.loanPayment(loanId));
    }

    @PostMapping("/closeOutLoan")
    public @ResponseBody
    GenericResponse closeOutLoan(@RequestParam Long loanId) {
        return createSuccessResponse(loanProcessingSystem.closeOutLoan(loanId));
    }

}
