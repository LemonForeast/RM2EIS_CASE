package com.loanprocessingsystem.repository;

import com.loanprocessingsystem.model.entity.Loan;
import com.loanprocessingsystem.model.enums.LoanStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface LoanRepository extends JpaRepository<Loan, Long> {
    Optional<Loan> findById(Long id);

    List<Loan> findAll();

    List<Loan> findAllByStatusAndCurrentOverDueDateLessThan(LoanStatus loanStatus, LocalDate date);

    Loan save(Loan loan);

    void delete(Loan loan);
}