package com.loanprocessingsystem.service;

import com.loanprocessingsystem.model.entity.CheckingAccount;
import com.loanprocessingsystem.model.entity.CreditHistory;
import com.loanprocessingsystem.model.entity.LoanRequest;
import com.loanprocessingsystem.model.enums.CheckingAccountStatus;
import com.loanprocessingsystem.model.enums.LoanRequestStatus;
import com.loanprocessingsystem.repository.CheckingAccountRepository;
import com.loanprocessingsystem.repository.CreditHistoryRepository;
import com.loanprocessingsystem.repository.LoanRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SubmitLoanRequestModule {

    private LoanRequestRepository loanRequestRepository;

    private CreditHistoryRepository creditHistoryRepository;

    private CheckingAccountRepository checkingAccountRepository;

    @Autowired
    public SubmitLoanRequestModule(LoanRequestRepository loanRequestRepository,
                                   CreditHistoryRepository creditHistoryRepository,
                                   CheckingAccountRepository checkingAccountRepository) {
        this.loanRequestRepository = loanRequestRepository;
        this.creditHistoryRepository = creditHistoryRepository;
        this.checkingAccountRepository = checkingAccountRepository;
    }

    public boolean enterLoanInformation(Long requestId, String name, double loanAmount, String loanPurpose,
                                        Double income, int phoneNumber, String postalAddress,
                                        int zipcode, String email, String workReferences, String creditReferences,
                                        int checkingAccountNumber, int securityNumber) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(requestId);
        boolean result = false;
        if (optionalLoanRequest.isEmpty()) {
            LoanRequest loanRequest = new LoanRequest();
            loanRequest.setId(requestId);
            loanRequest.setName(name);
            loanRequest.setLoanAmount(loanAmount);
            loanRequest.setLoanPurpose(loanPurpose);
            loanRequest.setIncome(income);
            loanRequest.setPhoneNumber(phoneNumber);
            loanRequest.setPostalAddress(postalAddress);
            loanRequest.setZipCode(zipcode);
            loanRequest.setEmail(email);
            loanRequest.setWorkReferences(workReferences);
            loanRequest.setCreditReferences(creditReferences);
            loanRequest.setCheckingAccountNumber(checkingAccountNumber);
            loanRequest.setSecurityNumber(securityNumber);

            loanRequestRepository.save(loanRequest);

            result = true;
        }
        return result;
    }

    public boolean creditRequest(Long id, double outstandingDebits, int badDebits,
                                 int securityNumber, String name) {
        Optional<LoanRequest> optionalLoanRequest =
                loanRequestRepository.findLoanRequestBySecurityNumberAndName(securityNumber, name);
        boolean result = false;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();
            if (loanRequest.getRequestedCreditHistory() == null) {
                CreditHistory creditHistory = new CreditHistory(id, outstandingDebits, badDebits);
                loanRequest.setRequestedCreditHistory(creditHistory);

                creditHistoryRepository.save(creditHistory);
                loanRequestRepository.save(loanRequest);
                result = true;
            }
        }
        return result;
    }

    public boolean accountStatusRequest(Long id, double balance,
                                        CheckingAccountStatus checkingAccountStatus, int checkingAccountNumber) {
        Optional<LoanRequest> optionalLoanRequest =
                loanRequestRepository.findLoanRequestByCheckingAccountNumber(checkingAccountNumber);
        boolean result = false;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();
            if (loanRequest.getRequestedCAHistory() == null) {
                CheckingAccount checkingAccount = new CheckingAccount(id, balance, checkingAccountStatus);
                loanRequest.setRequestedCAHistory(checkingAccount);

                checkingAccountRepository.save(checkingAccount);
                loanRequestRepository.save(loanRequest);
                result = true;
            }
        }
        return result;
    }

    public int calculateScore(Long id) {
        Optional<LoanRequest> optionalLoanRequest = loanRequestRepository.findById(id);
        int creditSocre = 0;
        if (optionalLoanRequest.isPresent()) {
            LoanRequest loanRequest = optionalLoanRequest.get();
            if (loanRequest.getRequestedCAHistory() != null
                    && loanRequest.getRequestedCreditHistory() != null) {
                creditSocre = 100;
                loanRequest.setCreditScore(creditSocre);
                loanRequest.setLoanRequestStatus(LoanRequestStatus.SUBMITTED);
                loanRequestRepository.save(loanRequest);
            }
        }
        return creditSocre;
    }
}
