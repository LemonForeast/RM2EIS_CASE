package com.loanprocessingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanProcessingSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoanProcessingSystemApplication.class, args);
    }

}
