package com.loanprocessingsystem.controller;

import com.loanprocessingsystem.controller.generic.GenericController;
import com.loanprocessingsystem.controller.generic.response.GenericResponse;
import com.loanprocessingsystem.service.EvaluateLoanRequestModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/evaluateLoanRequestModule",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class EvaluateLoanRequestModuleController extends GenericController {

    private final EvaluateLoanRequestModule evaluateLoanRequestModule;

    @Autowired
    public EvaluateLoanRequestModuleController(EvaluateLoanRequestModule evaluateLoanRequestModule) {
        this.evaluateLoanRequestModule = evaluateLoanRequestModule;
    }

    @GetMapping("/list")
    public @ResponseBody
    GenericResponse listTenLoanRequest() {
        return createSuccessResponse(evaluateLoanRequestModule.listTenLoanRequest());
    }

    @GetMapping("/choose")
    public @ResponseBody
    GenericResponse chooseOneForReview(@RequestParam Long requestId) {
        return createSuccessResponse(evaluateLoanRequestModule.chooseOneForReview(requestId));
    }

    @GetMapping("/checkCreditHistory")
    public @ResponseBody
    GenericResponse checkCreditHistory(@RequestParam Long requestId) {
        return createSuccessResponse(evaluateLoanRequestModule.checkCreditHistory(requestId));
    }

    @GetMapping("/reviewCheckingAccount")
    public @ResponseBody
    GenericResponse reviewCheckingAccount(@RequestParam Long requestId) {
        return createSuccessResponse(evaluateLoanRequestModule.reviewCheckingAccount(requestId));
    }

    @GetMapping("/listAvaiableLoanTerm")
    public @ResponseBody
    GenericResponse listAvaiableLoanTerm() {
        return createSuccessResponse(evaluateLoanRequestModule.listAvaiableLoanTerm());
    }

    @PostMapping("/approveLoanRequest")
    public @ResponseBody
    GenericResponse approveLoanRequest(@RequestParam Long requestId) {
        return createSuccessResponse(evaluateLoanRequestModule.approveLoanRequest(requestId));
    }

}
