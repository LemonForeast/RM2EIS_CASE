package com.loanprocessingsystem.model.entity;

import com.loanprocessingsystem.model.enums.LoanStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class Loan {
    @Id
    private Long id;
    private double remainAmountToPay;
    @Enumerated(EnumType.STRING)
    private LoanStatus status;
    private boolean isPaidInFull;
    private LocalDate startDate;
    private LocalDate endDate;
    private LocalDate currentOverDueDate;
    private int repaymentDays;
    private double repaymentAmount;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private LoanAccount belongedLoanAccount;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private LoanRequest referedLoanRequest;


}
