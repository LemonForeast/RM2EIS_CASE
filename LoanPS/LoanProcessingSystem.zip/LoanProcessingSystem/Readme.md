1- First, you need to package this application with below command.

maven package

2- To create an image from Dockerfile, you should open a terminal in root directory of the project.
After that, you must run below command. 

docker build . -t loanprocessingsystem

3- To run this image as a container, you can use the following command.

docker run --publish 8080:8080 loanprocessingsystem

After doing that, you can access the application from localhost:8080.

Note: I pushed my loanprocessingsystem image to my public docker registry. So, If you have kubernetes locally,
you can just run loanprocessingsystem-kube.yaml file with below command:

kubectl create -f loanprocessingsystem-kube.yaml

I deployed loanprocessingsystem image in kubernetes cluster with kind. You can see the details below about this image.

yigitcannalci@yigitcannalci:~/dev/workspace/LoanProcessingSystem$ kubectl describe pod loankube
Name:         loankube
Namespace:    default
Priority:     0
Node:         kind-control-plane/172.19.0.2
Start Time:   Fri, 24 Jun 2022 21:38:59 +0300
Labels:       <none>
Annotations:  <none>
Status:       Running
IP:           10.244.0.12
IPs:
IP:  10.244.0.12
Containers:
loanprocessingsystem:
Container ID:   containerd://00ed92205adc0af071f887c5826edb8b1bce7615f9c7ee516c303187973a482b
Image:          ragcrix/my-repo:latest
Image ID:       docker.io/ragcrix/my-repo@sha256:16dd1a15c71649168dd170052c620fd9fb137f557deb9e7b68c0fdbeb4a56d2c
Port:           80/TCP
Host Port:      0/TCP
State:          Running
Started:      Fri, 24 Jun 2022 21:40:41 +0300
Ready:          True
Restart Count:  0
Environment:    <none>
Mounts:
/var/run/secrets/kubernetes.io/serviceaccount from kube-api-access-gc5zq (ro)
Conditions:
Type              Status
Initialized       True
Ready             True
ContainersReady   True
PodScheduled      True
Volumes:
kube-api-access-gc5zq:
Type:                    Projected (a volume that contains injected data from multiple sources)
TokenExpirationSeconds:  3607
ConfigMapName:           kube-root-ca.crt
ConfigMapOptional:       <nil>
DownwardAPI:             true
QoS Class:                   BestEffort
Node-Selectors:              <none>
Tolerations:                 node.kubernetes.io/not-ready:NoExecute op=Exists for 300s
node.kubernetes.io/unreachable:NoExecute op=Exists for 300s
Events:
Type    Reason     Age    From               Message
  ----    ------     ----   ----               -------
Normal  Scheduled  5m29s  default-scheduler  Successfully assigned default/loankube to kind-control-plane
Normal  Pulling    5m28s  kubelet            Pulling image "ragcrix/my-repo:latest"
Normal  Pulled     3m47s  kubelet            Successfully pulled image "ragcrix/my-repo:latest" in 1m40.941948843s
Normal  Created    3m47s  kubelet            Created container loanprocessingsystem
Normal  Started    3m47s  kubelet            Started container loanprocessingsystem
yigitcannalci@yigitcannalci:~/dev/workspace/LoanProcessingSystem$ kubectl get pods
NAME       READY   STATUS    RESTARTS   AGE
loankube   1/1     Running   0          10m

