package com.example.microknowledgesystemservice.util;


public class Constant {


}
