package com.example.microknowledgesystemservice.api.service;

public class ThirdPartyServices {
}
