## To Start App

```
mvn -e clean package
docker create network test
docker-compose up
```

