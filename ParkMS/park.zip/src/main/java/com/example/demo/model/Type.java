package com.example.demo.model;

public enum Type {
    SMALL,
    LARGE,
    MOTOCYCLE,
    SPECIAL
}
