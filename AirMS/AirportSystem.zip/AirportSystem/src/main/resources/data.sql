-- staff
INSERT INTO STAFF (id, name, password, phone, role, boss_id) VALUES (-3, 'michael', 'michael', '2525', 'MASTER', null);
INSERT INTO STAFF (id, name, password, phone, role, boss_id) VALUES (-1, 'yigitcan', 'yigit', '2323', 'MANAGER', -3);
INSERT INTO STAFF (id, name, password, phone, role, boss_id) VALUES (-2, 'ryan', 'ryan', '2424', 'WORKER', -1);

-- device
INSERT INTO DEVICE (id, location, name, contact_id) VALUES (-1, 'hangar', '	landing gears', -2);


-- repair
INSERT INTO REPAIR (id, close, description, fail_time, price, process,
                    repair_name, result, score, raise_staff_id, related_device_id)
VALUES (-1, false, 'landing gears does not open', '2022-10-22 14:38:35', 1000.0, 'STAFF_REQUEST', 'fix landing gears', null, -1, -2, -1);

