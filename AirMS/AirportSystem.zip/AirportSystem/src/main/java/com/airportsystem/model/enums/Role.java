package com.airportsystem.model.enums;

public enum Role {
    ZERO(0, "Zero"),
    MASTER(1, "Master"),
    MANAGER(2, "Manager"),
    WORKER(3, "Worker");

    private final int code;
    private final String name;

    Role(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static Role getRole(int code) {
        return switch (code) {
            case 1 -> Role.MASTER;
            case 2 -> Role.MANAGER;
            case 3 -> Role.WORKER;
            default -> throw new IllegalArgumentException("There is not this code for Role enum!");
        };
    }
}
