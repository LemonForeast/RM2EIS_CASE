package com.airportsystem.model.entity;

import com.airportsystem.model.enums.Process;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class Repair {
    @Id
    private Long id;
    private String repairName;
    private Double price;
    private String description;
    private int score;
    private LocalDateTime failTime;
    private boolean close;
    @Enumerated(EnumType.STRING)
    private Process process;
    private String result;
    @OneToMany
    private List<ApprovalHistory> history;
    @OneToOne
    private Device relatedDevice;
    @OneToOne
    private Staff raiseStaff;
}
