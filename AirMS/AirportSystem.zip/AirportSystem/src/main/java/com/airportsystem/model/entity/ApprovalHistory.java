package com.airportsystem.model.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class ApprovalHistory {
    @Id
    private Long id;
    private Long staffId;
    private boolean reject;
    private String suggestion;
}
