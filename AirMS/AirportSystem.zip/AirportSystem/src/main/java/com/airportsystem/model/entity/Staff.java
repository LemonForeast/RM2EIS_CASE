package com.airportsystem.model.entity;

import com.airportsystem.model.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class Staff {
    @Id
    private Long id;
    private String name;
    private String password;
    private String phone;
    @Enumerated(EnumType.STRING)
    private Role role;
    @OneToOne
    private Staff boss;
}
