package com.airportsystem.service;

import com.airportsystem.model.entity.Device;
import com.airportsystem.model.entity.Staff;
import com.airportsystem.model.enums.Role;
import com.airportsystem.repository.DeviceRepository;
import com.airportsystem.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * this service includes these methods: createStaff and createDevice
 */
@Service
public class AirportSystemService {

    private final StaffRepository staffRepository;
    private final DeviceRepository deviceRepository;

    @Autowired
    public AirportSystemService(StaffRepository staffRepository, DeviceRepository deviceRepository) {
        this.staffRepository = staffRepository;
        this.deviceRepository = deviceRepository;
    }

    public boolean createStaff(Long id, String name, String password,
                               String phone, int role, Long bossId) {
        Optional<Staff> optionalStaff = staffRepository.findById(id);
        Optional<Staff> optionalBoss = staffRepository.findById(bossId);
        if (optionalStaff.isEmpty()) {
            Staff boss = optionalBoss.get();
            Staff newStaff = new Staff(id, name, password, phone, Role.getRole(role), boss);
            staffRepository.save(newStaff);
            return true;
        }
        return false;
    }

    public boolean createDevice(Long id, String name, String location, Long contactId) {
        Optional<Device> optionalDevice = deviceRepository.findById(id);
        Optional<Staff> optionalContact = staffRepository.findById(contactId);
        Staff contact;
        if (optionalDevice.isEmpty()) {
            contact = optionalContact.get();
            Device newDevice = new Device(id, name, location, contact);
            deviceRepository.save(newDevice);
            return true;
        }

        return false;
    }

}
