package com.airportsystem.service;

import com.airportsystem.model.entity.ApprovalHistory;
import com.airportsystem.model.entity.Device;
import com.airportsystem.model.entity.Repair;
import com.airportsystem.model.entity.Staff;
import com.airportsystem.model.enums.Process;
import com.airportsystem.model.enums.Role;
import com.airportsystem.repository.ApprovalHistoryRepository;
import com.airportsystem.repository.DeviceRepository;
import com.airportsystem.repository.RepairRepository;
import com.airportsystem.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;

/**
 * this service includes these methods: approve, finishRepair, feedback
 */
@Service
public class RepairService {

    private final ApprovalHistoryRepository approvalHistoryRepository;
    private final StaffRepository staffRepository;
    private final RepairRepository repairRepository;
    private final DeviceRepository deviceRepository;

    @Autowired
    public RepairService(ApprovalHistoryRepository approvalHistoryRepository,
                         StaffRepository staffRepository, RepairRepository repairRepository,
                         DeviceRepository deviceRepository) {
        this.approvalHistoryRepository = approvalHistoryRepository;
        this.staffRepository = staffRepository;
        this.repairRepository = repairRepository;
        this.deviceRepository = deviceRepository;
    }

    public ApprovalHistory approve(Long id, Long sid, Long rid, boolean reject, String suggestion) {
        Optional<Staff> optionalStaff = staffRepository.findById(sid);
        Optional<Repair> optionalRepair = repairRepository.findById(rid);

        if (optionalStaff.isPresent() && optionalRepair.isPresent()) {
            ApprovalHistory approvalHistory = new ApprovalHistory(id, sid, reject, suggestion);
            approvalHistoryRepository.save(approvalHistory);
            Staff staff = optionalStaff.get();
            Repair repair = optionalRepair.get();
            if (!reject) {
                if (Process.STAFF_REQUEST == repair.getProcess()
                        && Role.MASTER == staff.getRole()) {
                    repair.setProcess(Process.MASTER_APPROVE);
                } else if (Process.MASTER_APPROVE == repair.getProcess()
                        && Role.MANAGER == staff.getRole()) {
                    repair.setProcess(Process.MANAGER_APPROVE);
                } else if (Process.MANAGER_APPROVE == repair.getProcess()
                        && Role.WORKER == staff.getRole()) {
                    repair.setProcess(Process.WORKER_APPROVE);
                }
            } else {
                repair.setProcess(Process.REJECT);
            }
            repairRepository.save(repair);
            return approvalHistory;
        }
        return null;
    }

    public boolean finishRepair(Long id, Long sid, Long did, String res) {
        Optional<Repair> optionalRepair = repairRepository.findById(id);
        Optional<Staff> optionalStaff = staffRepository.findById(sid);
        Optional<Device> optionalDevice = deviceRepository.findById(did);
        boolean result = false;
        if (optionalStaff.isPresent() && optionalRepair.isPresent()
                && optionalDevice.isPresent()) {
            Staff staff = optionalStaff.get();
            Repair repair = optionalRepair.get();
            Device device = optionalDevice.get();

            if (Objects.equals(device.getContact().getId(), staff.getId())
                    && Role.WORKER == staff.getRole()) {
                repair.setProcess(Process.FINISH);
                repairRepository.save(repair);
                result = true;
            }
        }
        return result;
    }

    public boolean feedback(Long id, Long sid, int score, String des) {
        Optional<Repair> optionalRepair = repairRepository.findById(id);
        Optional<Staff> optionalStaff = staffRepository.findById(sid);

        boolean result = false;
        if (optionalStaff.isPresent() && optionalRepair.isPresent()) {
            Staff staff = optionalStaff.get();
            Repair repair = optionalRepair.get();

            if (Objects.equals(repair.getRaiseStaff().getId(), staff.getId())
                    && Role.ZERO == staff.getRole()
                    && Process.FINISH == repair.getProcess()) {
                repair.setScore(score);
                if (score > 3) {
                    repair.setClose(true);
                } else {
                    repair.setClose(false);
                    repair.setDescription(des);
                    repair.setProcess(Process.STAFF_REQUEST);
                }
                repairRepository.save(repair);
                result = true;
            }
        }
        return result;
    }

}
