package com.airportsystem.controller;

import com.airportsystem.controller.generic.GenericController;
import com.airportsystem.controller.generic.response.GenericResponse;
import com.airportsystem.service.RepairService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/repair",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class RepairController extends GenericController {

    private final RepairService repairService;

    @Autowired
    public RepairController(RepairService repairService) {
        this.repairService = repairService;
    }

    @PostMapping("/approve")
    public @ResponseBody
    GenericResponse approve(@RequestParam Long id, @RequestParam Long sid,
                            @RequestParam Long rid, @RequestParam boolean reject,
                            @RequestParam String suggestion) {
        repairService.approve(id, sid, rid, reject, suggestion);
        return createSuccessResponse("Repair request approved!");
    }

    @PostMapping("/finishRepair")
    public @ResponseBody
    GenericResponse finishRepair(@RequestParam Long id, @RequestParam Long sid,
                                 @RequestParam Long did, @RequestParam String res) {
        repairService.finishRepair(id, sid, did, res);
        return createSuccessResponse("The repair finished!");
    }

    @PostMapping("/feedback")
    public @ResponseBody
    GenericResponse feedback(@RequestParam Long id, @RequestParam Long sid,
                             @RequestParam int score, @RequestParam String des) {
        repairService.feedback(id, sid, score, des);
        return createSuccessResponse("Feedback received!");
    }
}
