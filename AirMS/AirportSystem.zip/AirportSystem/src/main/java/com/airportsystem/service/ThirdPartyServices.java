package com.airportsystem.service;

import org.springframework.stereotype.Service;

/**
 * this service includes these methods: ...
 */
@Service
public class ThirdPartyServices {

}
