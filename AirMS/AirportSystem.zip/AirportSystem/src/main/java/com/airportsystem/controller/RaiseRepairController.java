package com.airportsystem.controller;

import com.airportsystem.controller.generic.GenericController;
import com.airportsystem.controller.generic.response.GenericResponse;
import com.airportsystem.service.RaiseRepairService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping(value = "/raiseRepair",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class RaiseRepairController extends GenericController {

    private final RaiseRepairService raiseRepairService;

    @Autowired
    public RaiseRepairController(RaiseRepairService raiseRepairService) {
        this.raiseRepairService = raiseRepairService;
    }

    @PostMapping("/submitRequest")
    public @ResponseBody
    GenericResponse submitRequest(@RequestParam Long id, @RequestParam Long did,
                                  @RequestParam String repairName, @RequestParam Double price,
                                  @RequestParam String desc,
                                  @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime failTime) {
        raiseRepairService.submitRequest(id, did, repairName, price, desc, failTime);
        return createSuccessResponse("Repair request saved!");
    }
}
