package com.airportsystem.repository;

import com.airportsystem.model.entity.ApprovalHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApprovalHistoryRepository extends JpaRepository<ApprovalHistory, Long> {
    Optional<ApprovalHistory> findById(Long id);

    List<ApprovalHistory> findAll();

    ApprovalHistory save(ApprovalHistory approvalHistory);

    void delete(ApprovalHistory approvalHistory);
}