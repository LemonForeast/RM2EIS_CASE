package com.airportsystem.model.enums;

public enum Process {
    STAFF_REQUEST(0, "Staff Request"),
    MASTER_APPROVE(1, "Master Approve"),
    MANAGER_APPROVE(2, "Manager Approve"),
    WORKER_APPROVE(3, "Worker Approve"),
    REJECT(5, "Reject"),
    
    FINISH(7, "Finish");

    private final int code;
    private final String name;

    Process(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}
