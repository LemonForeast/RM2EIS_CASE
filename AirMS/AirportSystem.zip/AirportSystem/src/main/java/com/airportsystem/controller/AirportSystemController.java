package com.airportsystem.controller;

import com.airportsystem.controller.generic.GenericController;
import com.airportsystem.controller.generic.response.GenericResponse;
import com.airportsystem.service.AirportSystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/airportSystem",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class AirportSystemController extends GenericController {

    private final AirportSystemService airportSystemService;

    @Autowired
    public AirportSystemController(AirportSystemService airportSystemService) {
        this.airportSystemService = airportSystemService;
    }

    @PostMapping("/createStaff")
    public @ResponseBody
    GenericResponse createStaff(@RequestParam Long staffId, @RequestParam String name,
                                @RequestParam String password, @RequestParam String phone,
                                @RequestParam int role, @RequestParam Long bossId) {
        airportSystemService.createStaff(staffId, name, password, phone, role, bossId);
        return createSuccessResponse("Staff created!");
    }

    @PostMapping("/createDevice")
    public @ResponseBody
    GenericResponse createDevice(@RequestParam Long deviceId, @RequestParam String name,
                                @RequestParam String location, @RequestParam Long contactId) {
        airportSystemService.createDevice(deviceId, name, location, contactId);
        return createSuccessResponse("Device created!");
    }
}
