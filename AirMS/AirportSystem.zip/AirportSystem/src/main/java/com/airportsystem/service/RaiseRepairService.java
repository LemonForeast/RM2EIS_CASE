package com.airportsystem.service;

import com.airportsystem.model.entity.Device;
import com.airportsystem.model.entity.Repair;
import com.airportsystem.model.enums.Process;
import com.airportsystem.repository.DeviceRepository;
import com.airportsystem.repository.RepairRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * this service includes these methods: submitRequest, managerApprove1, masterApprove ,managerReject
 * managerApprove2, masterReject
 */
@Slf4j
@Service
public class RaiseRepairService {

    private final RepairRepository repairRepository;
    private final DeviceRepository deviceRepository;

    private final RepairService repairService;

    @Autowired
    public RaiseRepairService(RepairRepository repairRepository, DeviceRepository deviceRepository, RepairService repairService) {
        this.repairRepository = repairRepository;
        this.deviceRepository = deviceRepository;
        this.repairService = repairService;
    }

    public boolean submitRequest(Long id, Long did, String repairName, Double price, String desc, LocalDateTime failTime) {
        Optional<Device> optionalDevice = deviceRepository.findById(did);
        boolean result = false;
        if (optionalDevice.isPresent()) {
            Device device = optionalDevice.get();
            Repair repair = new Repair();
            repair.setId(id);
            repair.setRepairName(repairName);
            repair.setPrice(price);
            repair.setDescription(desc);
            repair.setFailTime(failTime);
            repair.setRelatedDevice(device);
            repair.setProcess(Process.STAFF_REQUEST);

            repairRepository.save(repair);

            result = true;
        }
        return result;
    }

    public void managerApprove1(Long id, Long sid, Long rid, boolean reject, String suggestion) {
        repairService.approve(id, sid, rid, reject, suggestion);
    }

    public void managerReject(Long id, Long sid, Long rid, boolean reject, String suggestion) {
        repairService.approve(id, sid, rid, reject, suggestion);
    }

    public void managerApprove2(Long id, Long sid, Long rid, boolean reject, String suggestion) {
        repairService.approve(id, sid, rid, reject, suggestion);

    }

    public void masterApprove(Long id, Long sid, Long rid, boolean reject, String suggestion) {
        repairService.approve(id, sid, rid, reject, suggestion);

    }

    public void masterReject(Long id, Long sid, Long rid, boolean reject, String suggestion) {
        repairService.approve(id, sid, rid, reject, suggestion);

    }


}