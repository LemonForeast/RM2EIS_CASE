package com.airportsystem.controller;

import com.airportsystem.model.entity.ApprovalHistory;
import com.airportsystem.service.RepairService;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(RepairController.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RepairControllerTest {

    private final Long approveId = 1L;
    private final Long sid = 1L;
    private final Long rid = 1L;
    private final boolean reject = false;
    private final String suggestion = "nothing";

    private final Long did = 1L;
    private final String res = "res";

    private final int score = -1;
    private final String des = "des";

    @Autowired
    private MockMvc mvc;
    @MockBean
    private RepairService repairService;

    @BeforeAll
    public void setup() {
        ApprovalHistory approvalHistory = new ApprovalHistory(approveId, sid, reject, suggestion);

        Mockito.when(repairService.approve(
                approveId, sid, rid, reject, suggestion)).thenReturn(approvalHistory);
        Mockito.when(repairService.finishRepair(rid, sid, did, res)).thenReturn(true);
        Mockito.when(repairService.feedback(rid, sid, score, des)).thenReturn(true);

    }

    @Test
    void testApprove() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/repair/approve")
                        .param("id", String.valueOf(approveId))
                        .param("sid", String.valueOf(sid))
                        .param("rid", String.valueOf(rid))
                        .param("reject", String.valueOf(reject))
                        .param("suggestion", suggestion)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testFinishRepair() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/repair/finishRepair")
                        .param("id", String.valueOf(rid))
                        .param("sid", String.valueOf(sid))
                        .param("did", String.valueOf(did))
                        .param("res", res)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testFeedback() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/repair/feedback")
                        .param("id", String.valueOf(rid))
                        .param("sid", String.valueOf(sid))
                        .param("score", String.valueOf(score))
                        .param("des", des)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

}
