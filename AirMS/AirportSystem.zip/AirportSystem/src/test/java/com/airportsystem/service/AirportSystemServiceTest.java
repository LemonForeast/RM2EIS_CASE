package com.airportsystem.service;

import com.airportsystem.model.entity.Device;
import com.airportsystem.model.entity.Staff;
import com.airportsystem.model.enums.Role;
import com.airportsystem.repository.DeviceRepository;
import com.airportsystem.repository.StaffRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AirportSystemServiceTest {

    private final Long staffId = 1L;
    private final String staffName = "yigitcan";
    private final String password = "abc123";
    private final String phone = "5321";
    private final int role = 1;
    private final Long bossId = 2L;

    private final Long deviceId = 1L;
    private final String deviceName = "gears";
    private final String location = "carolina";
    private final Long contactId = 3L;

    private Staff bossStaff;
    private Staff newStaff;
    private Staff contactStaff;

    private Device newDevice;

    private AirportSystemService airportSystemService;
    @MockBean
    private StaffRepository staffRepository;
    @MockBean
    private DeviceRepository deviceRepository;

    @BeforeAll
    public void setup() {
        airportSystemService = new AirportSystemService(staffRepository, deviceRepository);

        bossStaff = new Staff();
        bossStaff.setId(bossId);

        contactStaff = new Staff();
        contactStaff.setId(contactId);

        newStaff = new Staff(staffId, staffName, password, phone, Role.getRole(role), bossStaff);
        newDevice = new Device(deviceId, deviceName, location, contactStaff);
    }

    @Test
    void testCreateStaff_thenProcessShouldBeSuccessful() {
        Mockito.when(staffRepository.findById(bossId)).thenReturn(Optional.of(bossStaff));
        Mockito.when(staffRepository.findById(staffId)).thenReturn(Optional.empty());
        Mockito.when(staffRepository.save(newStaff)).thenReturn(newStaff);
        boolean result = airportSystemService.
                createStaff(staffId, staffName, password, phone, role, bossId);

        assertTrue(result);
    }

    @Test
    void testCreateDevice_thenProcessShouldBeSuccessful() {
        Mockito.when(deviceRepository.findById(deviceId)).thenReturn(Optional.empty());
        Mockito.when(staffRepository.findById(contactId)).thenReturn(Optional.of(contactStaff));
        Mockito.when(deviceRepository.save(newDevice)).thenReturn(newDevice);
        boolean result = airportSystemService.createDevice(deviceId, deviceName, location, contactId);

        assertTrue(result);
    }

}
