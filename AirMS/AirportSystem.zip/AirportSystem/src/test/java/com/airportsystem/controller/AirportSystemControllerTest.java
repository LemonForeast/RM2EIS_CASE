package com.airportsystem.controller;

import com.airportsystem.service.AirportSystemService;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(AirportSystemController.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AirportSystemControllerTest {

    private final Long staffId = 1L;
    private final String staffName = "yigitcan";
    private final String password = "abc123";
    private final String phone = "5321";
    private final int role = 1;
    private final Long bossId = 1L;

    private final Long deviceId = 1L;
    private final String deviceName = "gears";
    private final String location = "carolina";
    private final Long contactId = 1L;

    @Autowired
    private MockMvc mvc;
    @MockBean
    private AirportSystemService airportSystemService;

    @BeforeAll
    public void setup() {
        Mockito.when(airportSystemService.createStaff(
                staffId, staffName, password, phone, role, bossId)).thenReturn(true);
        Mockito.when(airportSystemService.createDevice(
                deviceId, deviceName, location, contactId)).thenReturn(true);
    }

    @Test
    void testCreateStaff() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/airportSystem/createStaff")
                        .param("staffId", String.valueOf(staffId))
                        .param("name", staffName)
                        .param("password", password)
                        .param("phone", phone)
                        .param("role", String.valueOf(role))
                        .param("bossId", String.valueOf(bossId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

    @Test
    void testCreateDevice() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/airportSystem/createDevice")
                        .param("deviceId", String.valueOf(deviceId))
                        .param("name", deviceName)
                        .param("location", location)
                        .param("contactId", String.valueOf(contactId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

}
