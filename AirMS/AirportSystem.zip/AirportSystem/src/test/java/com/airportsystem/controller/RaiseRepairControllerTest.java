package com.airportsystem.controller;

import com.airportsystem.service.RaiseRepairService;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(RaiseRepairController.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RaiseRepairControllerTest {

    private final Long repairId = 1L;
    private final Long did = 1L;

    private final String repairName = "Gears problem";
    private final Double price = 1000.0;
    private final String desc = "Landing gears problem";

    private final LocalDateTime failTime = LocalDateTime.now();

    @Autowired
    private MockMvc mvc;
    @MockBean
    private RaiseRepairService raiseRepairService;

    @BeforeAll
    public void setup() {
        Mockito.when(raiseRepairService.submitRequest(
                repairId, did, repairName, price, desc, failTime)).thenReturn(true);
    }

    @Test
    void testApprove() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.post("/raiseRepair/submitRequest")
                        .param("id", String.valueOf(repairId))
                        .param("did", String.valueOf(did))
                        .param("repairName", repairName)
                        .param("price", String.valueOf(price))
                        .param("desc", desc)
                        .param("failTime", String.valueOf(failTime))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String resultString = result.getResponse().getContentAsString();
        assertNotNull(resultString);
    }

}
