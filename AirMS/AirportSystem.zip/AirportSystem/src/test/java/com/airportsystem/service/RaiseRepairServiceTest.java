package com.airportsystem.service;

import com.airportsystem.model.entity.Device;
import com.airportsystem.repository.DeviceRepository;
import com.airportsystem.repository.RepairRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RaiseRepairServiceTest {

    private final Long repairId = 1L;
    private final Long did = 1L;

    private final String repairName = "Gears problem";
    private final Double price = 1000.0;
    private final String desc = "Landing gears problem";
    private final LocalDateTime failTime = LocalDateTime.now();

    private Device device;

    private RaiseRepairService raiseRepairService;

    @MockBean
    private RepairService repairService;
    @MockBean
    private DeviceRepository deviceRepository;
    @MockBean
    private RepairRepository repairRepository;

    @BeforeAll
    public void setup() {
        raiseRepairService = new RaiseRepairService(repairRepository, deviceRepository, repairService);

        device = new Device();
        device.setId(did);
    }

    @Test
    void testSubmitRequest_thenProcessShouldBeSuccessful() {
        Mockito.when(deviceRepository.findById(did)).thenReturn(Optional.of(device));

        boolean result = raiseRepairService.
                submitRequest(repairId, did, repairName, price, desc, failTime);

        assertTrue(result);
    }

}
