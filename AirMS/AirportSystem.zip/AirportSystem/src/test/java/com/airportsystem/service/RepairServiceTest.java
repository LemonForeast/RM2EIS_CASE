package com.airportsystem.service;

import com.airportsystem.model.entity.ApprovalHistory;
import com.airportsystem.model.entity.Device;
import com.airportsystem.model.entity.Repair;
import com.airportsystem.model.entity.Staff;
import com.airportsystem.model.enums.Process;
import com.airportsystem.model.enums.Role;
import com.airportsystem.repository.ApprovalHistoryRepository;
import com.airportsystem.repository.DeviceRepository;
import com.airportsystem.repository.RepairRepository;
import com.airportsystem.repository.StaffRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RepairServiceTest {

    private final Long approveId = 1L;
    private final Long sid = 1L;
    private final Long rid = 1L;
    private final boolean reject = false;
    private final String suggestion = "nothing";

    private final Long did = 1L;
    private final String res = "res";

    private final int score = -1;
    private final String des = "des";

    private Staff staff;
    private Staff staffRoleZero;

    private Repair repair;

    private Device device;

    private ApprovalHistory approvalHistory;

    private RepairService repairService;
    @MockBean
    private StaffRepository staffRepository;
    @MockBean
    private DeviceRepository deviceRepository;
    @MockBean
    private ApprovalHistoryRepository approvalHistoryRepository;
    @MockBean
    private RepairRepository repairRepository;

    @BeforeAll
    public void setup() {
        repairService = new RepairService(
                approvalHistoryRepository, staffRepository, repairRepository, deviceRepository);

        staff = new Staff();
        staff.setId(sid);
        staff.setRole(Role.WORKER);

        staffRoleZero = new Staff();
        staffRoleZero.setId(sid);
        staffRoleZero.setRole(Role.ZERO);

        repair = new Repair();
        repair.setId(rid);
        repair.setRaiseStaff(staff);

        device = new Device();
        device.setId(did);
        device.setContact(staff);

        approvalHistory = new ApprovalHistory(approveId, sid, reject, suggestion);

    }

    @Test
    void testApprove_thenReturnApprovalHistoryObject() {
        Mockito.when(staffRepository.findById(sid)).thenReturn(Optional.of(staff));
        Mockito.when(repairRepository.findById(rid)).thenReturn(Optional.of(repair));
        ApprovalHistory returnedApprovalHistory = repairService.approve(approveId, sid, rid, reject, suggestion);

        assertNotNull(returnedApprovalHistory);
    }

    @Test
    void testFinishRepair_thenProcessShouldBeSuccessful() {
        Mockito.when(staffRepository.findById(sid)).thenReturn(Optional.of(staff));
        Mockito.when(repairRepository.findById(rid)).thenReturn(Optional.of(repair));
        Mockito.when(deviceRepository.findById(did)).thenReturn(Optional.of(device));
        boolean result = repairService.finishRepair(rid, sid, did, res);

        assertTrue(result);
    }

    @Test
    void testFeedback_thenProcessShouldBeSuccessful() {
        repair.setProcess(Process.FINISH);
        Mockito.when(staffRepository.findById(sid)).thenReturn(Optional.of(staffRoleZero));
        Mockito.when(repairRepository.findById(rid)).thenReturn(Optional.of(repair));
        boolean result = repairService.feedback(rid, sid, score, des);

        assertTrue(result);
    }

}
