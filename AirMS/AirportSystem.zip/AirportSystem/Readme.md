1- First, you need to package this application with below command.

maven package

2- To create an image from Dockerfile, you should open a terminal in root directory of the project.
After that, you must run below command. 

docker build . -t airportsystem

3- To run this image as a container, you can use the following command.

docker run --publish 8080:8080 airportsystem

After doing that, you can access the application from localhost:8080.

Note: You can use AirportSystem.postman_collection.json file to test endpoints using Postman.
