//package com.lms.librarymanagment;
//
//
//import com.lms.librarymanagment.domain.Student;
//import com.lms.librarymanagment.repository.StudentRepository;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
//import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
//
//@DataJpaTest
//@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
//public class StudentRepositoryTests {
//
//    @Autowired
//    private StudentRepository studentRepository;
//
//    @Test
//    public void saveStudentTest(){
//        Student student = Student.builder()
//
//
//    }
//
//}
