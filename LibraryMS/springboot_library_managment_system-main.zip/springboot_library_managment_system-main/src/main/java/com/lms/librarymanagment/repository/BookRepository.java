package com.lms.librarymanagment.repository;

public class BookRepository {
}
