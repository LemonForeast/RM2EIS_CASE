package com.lms.librarymanagment.service;

public interface StudentService {
}
