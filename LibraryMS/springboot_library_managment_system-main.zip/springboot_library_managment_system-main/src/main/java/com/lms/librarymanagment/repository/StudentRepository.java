package com.lms.librarymanagment.repository;

public interface StudentRepository {
}
