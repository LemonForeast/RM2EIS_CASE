package com.lms.librarymanagment.service;public class FacultyServiceImpl {
}
