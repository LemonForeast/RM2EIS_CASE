package com.lms.librarymanagment.domain;

public class Subject {
}
