package com.example.dlmodelsystemservice.util;

public class Constant {

}
