package com.example.dlmodelsystemservice.api.service;

import com.example.dlmodelsystemservice.api.controller.DlSystemController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class AskForAPIService {
    private static final Logger LOGGER = LogManager.getLogger(AskForAPIService.class);
}
